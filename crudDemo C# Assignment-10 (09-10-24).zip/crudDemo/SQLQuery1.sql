﻿create table employee
(
 eid int primary key not null identity,
 ename varchar(150),
 email varchar(100) not null unique,
 phno varchar(15),
 address varchar(200),
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP 
);

insert into employee(ename,email,phno,address) 
values('Vyshnavi','vyshnavi@gmail.com','9487293930','Bangalore'),
('Kavya','kavya@gmail.com','6301293930','Hyderabad'),
('Bhavya','bhavya@gmail.com','7620293930','Vijayawada'),
('Jahnavi','jahnavi@gmail.com','8037293930','Bangalore'),
('Sravya','sravya@gmail.com','6907293930','Pune'),
('Navya','navya@gmail.com','9987293930','Chennai');


