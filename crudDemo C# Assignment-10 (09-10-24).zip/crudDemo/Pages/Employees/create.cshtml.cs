using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyStore.Pages.Clients;
using System.Data.SqlClient;

namespace crudDemo.Pages.Employees
{
    public class createModel : PageModel
    {
        public EmployeeInfo employeeInfo = new EmployeeInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
        }

        public void OnPost()
        {
            employeeInfo.ename = Request.Form["ename"];
            employeeInfo.email = Request.Form["email"];
            employeeInfo.phno = Request.Form["phno"];
            employeeInfo.address = Request.Form["address"];

            if (employeeInfo.ename.Length == 0 || employeeInfo.email.Length == 0 ||
               employeeInfo.phno.Length == 0 || employeeInfo.address.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            //save the new client into the database
            try
            {
                String connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\VyshnaviAtthuluri\\Documents\\demo1.mdf;Integrated Security=True;Connect Timeout=30";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "INSERT INTO employee " +
                                 "(ename, email, phno, address) VALUES " +
                                 "(@ename, @email, @phno, @address);";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@ename", employeeInfo.ename);
                        command.Parameters.AddWithValue("@email", employeeInfo.email);
                        command.Parameters.AddWithValue("@phno", employeeInfo.phno);
                        command.Parameters.AddWithValue("@address", employeeInfo.address);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            employeeInfo.ename = ""; employeeInfo.email = ""; employeeInfo.phno = ""; employeeInfo.address = "";
            successMessage = "New Employee Added Succesfully";

            Response.Redirect("/Employees/Indexemp");
        }
    }
}
