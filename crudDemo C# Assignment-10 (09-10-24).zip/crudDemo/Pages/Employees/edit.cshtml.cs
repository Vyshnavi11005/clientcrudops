using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyStore.Pages.Clients;
using System.Data.SqlClient;

namespace crudDemo.Pages.Employees
{
    public class editModel : PageModel
    {
        public EmployeeInfo employeeInfo = new EmployeeInfo();
        public String errorMessage = "";
        public String successMessage = "";

        public void OnGet()
        {
            String eid = Request.Query["eid"];

            try
            {
                String connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\VyshnaviAtthuluri\\Documents\\demo1.mdf;Integrated Security=True;Connect Timeout=30";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM employee WHERE eid=@eid";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@eid", eid);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                employeeInfo.eid = "" + reader.GetInt32(0);
                                employeeInfo.ename = reader.GetString(1);
                                employeeInfo.email = reader.GetString(2);
                                employeeInfo.phno = reader.GetString(3);
                                employeeInfo.address = reader.GetString(4);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
            }
        }

        public void OnPost()
        {
            employeeInfo.eid = Request.Form["eid"];
            employeeInfo.ename = Request.Form["ename"];
            employeeInfo.email = Request.Form["email"];
            employeeInfo.phno = Request.Form["phno"];
            employeeInfo.address = Request.Form["address"];

            if (employeeInfo.eid.Length == 0 || employeeInfo.ename.Length == 0 ||
                employeeInfo.email.Length == 0 || employeeInfo.phno.Length == 0 ||
                employeeInfo.address.Length == 0)
            {
                errorMessage = "All fields are required";
                return;
            }

            try
            {
                String connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\VyshnaviAtthuluri\\Documents\\demo1.mdf;Integrated Security=True;Connect Timeout=30";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "UPDATE employee " +
                                 "SET ename=@ename, email=@email, phno=@phno, address=@address " +
                                 "WHERE eid=@eid";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@ename", employeeInfo.ename);
                        command.Parameters.AddWithValue("@email", employeeInfo.email);
                        command.Parameters.AddWithValue("@phno", employeeInfo.phno);
                        command.Parameters.AddWithValue("@address", employeeInfo.address);
                        command.Parameters.AddWithValue("@eid", employeeInfo.eid);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            Response.Redirect("/Employees/Indexemp");
        }

    }
}
