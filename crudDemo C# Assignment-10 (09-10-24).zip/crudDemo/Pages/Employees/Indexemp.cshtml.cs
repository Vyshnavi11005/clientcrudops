using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using MyStore.Pages.Clients;
using System;
using System.Collections.Generic;
using System.Data.SqlClient; //required for sql access

namespace crudDemo.Pages.Employees
{
    public class IndexempModel : PageModel
    {
        private readonly IConfiguration _configuration;
        public List<EmployeeInfo> listEmployees = new List<EmployeeInfo>();

        public IndexempModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void OnGet()
        {
            try
            {
                // Fetch the connection string from appsettings.json
                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "SELECT * FROM employee";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                EmployeeInfo empInfo = new EmployeeInfo
                                {
                                    eid = reader.GetInt32(0).ToString(),
                                    ename = reader.GetString(1),
                                    email = reader.GetString(2),
                                    phno = reader.GetString(3),
                                    address = reader.GetString(4),
                                    created_at = reader.GetDateTime(5).ToString()
                                };

                                listEmployees.Add(empInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
                // Optionally: Handle or log the exception appropriately
            }
        }
    }

    public class EmployeeInfo
    {
        public string eid;
        public string ename;
        public string email;
        public string phno;
        public string address;
        public string created_at;
    }
}
